clc
clear
close all
x=[-0.5 +0.5 +0.5 -0.5 -0.5 -0.5;
+0.5 +0.5 -0.5 -0.5 +0.5 +0.5; 
+0.5 +0.5 -0.5 -0.5 +0.5 +0.5;
-0.5 +0.5 +0.5 -0.5 -0.5 -0.5]; 
y=[-0.5 -0.5 +0.5 -0.5 -0.5 -0.5;
-0.5 +0.5 +0.5 +0.5 -0.5 -0.5;
-0.5 +0.5 +0.5 +0.5 +0.5 +0.5;
-0.5 -0.5 +0.5 -0.5 +0.5 +0.5]; 
z=[0 0 0 0 0 1;
0 0 0 0 0 1;
1 1 1 1 0 1;
1 1 1 1 0 1];
Orgcell1=[1 0 1    0  1 1 ];
Orgcell2=[0 0 0.46 1  1 1];
Orgcell3=[0 1 0    0  0 1 ];
Org1(:,1)=Orgcell1;
Org2(:,1)=Orgcell2;
Org3(:,1)=Orgcell3;
x1=ones(size(x))+x;
y1=ones(size(x))+y;
x2=-1*ones(size(x))+x;
y2=-1*ones(size(x))+y;
z1=ones(size(z))+z;
z2=-1*ones(size(z))+z;
Org(1,:,:)=[Org1 Org2 Org3 ];
Org(2,:,:)=[Org1 Org2 Org3 ];
Org(3,:,:)=[Org1 Org2 Org3 ];
Org(4,:,:)=[Org1 Org2 Org3 ];
h0=patch(x2,y1,z, Org);
hold on;
h1=patch(x,y1,z, Org);
h2=patch(x1,y1,z, Org);
h3=patch(x2,y,z, Org);
h4=patch(x,y,z, Org);
h5=patch(x1,y,z, Org);
h6=patch(x2,y2,z, Org);
h7=patch(x,y2,z, Org);
h8=patch(x1,y2,z, Org);
h10=patch(x2,y1,z1, Org);
h11=patch(x,y1,z1, Org);
h12=patch(x1,y1,z1, Org);
h13=patch(x2,y,z1, Org);
h14=patch(x,y,z1, Org);
h15=patch(x1,y,z1, Org);
h16=patch(x2,y2,z1, Org);
h17=patch(x,y2,z1, Org);
h18=patch(x1,y2,z1, Org);
h20=patch(x2,y1,z2, Org);
h21=patch(x,y1,z2, Org);
h22=patch(x1,y1,z2, Org);
h23=patch(x2,y,z2, Org);
h24=patch(x,y,z2, Org);
h25=patch(x1,y,z2, Org);
h26=patch(x2,y2,z2, Org);
h27=patch(x,y2,z2, Org);
h28=patch(x1,y2,z2, Org);
hold off;
axis equal tight 
axis([-4 4 -4 4 -4 4]);
title('?�졤?��???');
xlabel('Variable X');
ylabel('Variable Y');
zlabel('Variable Z');
grid on
%view(0,0);
origin=[0 0 0.5];
direct1=[0 1 0];
theta=-45;
H1=[h6  h7  h8;         %H1Ϊ��ɫ��
h16 h17 h18;
h26 h27 h28];
direct2=[0 0 1];
H2=[h20 h21  h22;       %H2Ϊ��ɫ��
h23 h24  h25;
h26 h27  h28];
direct3=[0 0 1];
H3=[h10 h11  h12;       %H3Ϊ��ɫ��
h13 h14  h15;
h16 h17  h18];
direct4=[1 0 0 ];
H4=[h2  h5   h8;       %H4Ϊ��ɫ��
h12 h15  h18;
h22 h25  h28];
direct5=[1 0 0 ];
H5=[h0  h3   h6;       %H5Ϊ��ɫ��
h10 h13  h16;
h20 h23  h26];
direct6=[0 1 0 ];
H6=[h0  h1   h2;       %H6Ϊ��ɫ��
h10 h11  h12;
h20 h21  h22];
for i=1:8
rotate(H6(:),direct6,theta,origin)
pause(0.2) 
end







