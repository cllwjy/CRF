 
clc; clear; close all;
[x y]=meshgrid([0:10]);
z1 = zeros(size(x));
z2 = ones(size(x))*10;
figure; hold on; view(3);
mesh(x, y, z1);
mesh(x, z1, y);
mesh(z1, x, y);
mesh(x, y, z2);
mesh(x, z2, y);
mesh(z2, x, y);
axis on
colormap lines
