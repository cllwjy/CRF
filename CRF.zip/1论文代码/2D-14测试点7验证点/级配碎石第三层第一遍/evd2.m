clear clc
%%
x=xlsread('data.xlsx','sheet1','b1:h21');
% ��Ƶ�ʷֲ�ֱ��ͼ
[counts,centers] = hist(x,5);
figure;
bar(centers,counts/sum(counts));
legend('Runway experimental section','Fontname', 'Times New Roman','FontSize',12);
xlabel('EVD/MPa','Fontname', 'Times New Roman','FontSize',12);
ylabel('Frequency ','Fontname', 'Times New Roman','FontSize',12);
hold on;
%%
x=xlsread('data.xlsx','sheet1','b1:b21');
% ��Ƶ�ʷֲ�ֱ��ͼ
[counts,centers] = hist(x,5);
figure;
bar(centers,counts/sum(counts));
legend('The third layer of graded crushed stone-pass 1','Fontname', 'Times New Roman','FontSize',12);
xlabel('EVD/MPa','Fontname', 'Times New Roman','FontSize',12);
ylabel('Frequency ','Fontname', 'Times New Roman','FontSize',12);
hold on;
%%
x=xlsread('data.xlsx','sheet1','c1:c21');
% ��Ƶ�ʷֲ�ֱ��ͼ
[counts,centers] = hist(x,5);
figure;
bar(centers,counts/sum(counts));
legend('The third layer of graded crushed stone-pass 2','Fontname', 'Times New Roman','FontSize',12);
xlabel('EVD/MPa','Fontname', 'Times New Roman','FontSize',12);
ylabel('Frequency ','Fontname', 'Times New Roman','FontSize',12);
hold on;
%%
x=xlsread('data.xlsx','sheet1','d1:d21');
% ��Ƶ�ʷֲ�ֱ��ͼ
[counts,centers] = hist(x,5);
figure;
bar(centers,counts/sum(counts));
legend('The third layer of graded crushed stone-pass 3','Fontname', 'Times New Roman','FontSize',12);
xlabel('EVD/MPa','Fontname', 'Times New Roman','FontSize',12);
ylabel('Frequency ','Fontname', 'Times New Roman','FontSize',12);
hold on;
%%
x=xlsread('data.xlsx','sheet1','e1:e21');
% ��Ƶ�ʷֲ�ֱ��ͼ
[counts,centers] = hist(x,5);
figure;
bar(centers,counts/sum(counts));
legend('The third layer of graded crushed stone-pass 4','Fontname', 'Times New Roman','FontSize',12);
xlabel('EVD/MPa','Fontname', 'Times New Roman','FontSize',12);
ylabel('Frequency ','Fontname', 'Times New Roman','FontSize',12);
hold on;
%%
x=xlsread('data.xlsx','sheet1','f1:f21');
% ��Ƶ�ʷֲ�ֱ��ͼ
[counts,centers] = hist(x,5);
figure;
bar(centers,counts/sum(counts));
legend('The third layer of graded crushed stone-final pass','Fontname', 'Times New Roman','FontSize',12);
xlabel('EVD/MPa','Fontname', 'Times New Roman','FontSize',12);
ylabel('Frequency ','Fontname', 'Times New Roman','FontSize',12);
hold on;
%%
x=xlsread('data.xlsx','sheet1','g1:g21');
% ��Ƶ�ʷֲ�ֱ��ͼ
[counts,centers] = hist(x,5);
figure;
bar(centers,counts/sum(counts));
legend('Cement stabilized macadam lower base -final pass','Fontname', 'Times New Roman','FontSize',12);
xlabel('EVD/MPa','Fontname', 'Times New Roman','FontSize',12);
ylabel('Frequency ','Fontname', 'Times New Roman','FontSize',12);
hold on;
%%
x=xlsread('data.xlsx','sheet1','h1:h21')
% ��Ƶ�ʷֲ�ֱ��ͼ
[counts,centers] = hist(x,5);
figure;
bar(centers,counts/sum(counts));
legend('Cement stabilized macadam upper base -final pass','Fontname', 'Times New Roman','FontSize',12);
xlabel('EVD/MPa','Fontname', 'Times New Roman','FontSize',12);
ylabel('Frequency','Fontname', 'Times New Roman','FontSize',12);
hold on;