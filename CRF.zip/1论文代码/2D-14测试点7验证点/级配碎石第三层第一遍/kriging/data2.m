clear clc 
close all
load data2.mat
%figure;
%plot(x,y,'.');
%title('ԭʼ��');
[X1,X2]=meshgrid(x);
[Y1,Y2]=meshgrid(y);
[Z1,Z2]=meshgrid(z);
D=sqrt((X1-X2).^2+(Y1-Y2).^2);

nugget=0;
sill=1;
range=40;

G_mod=(nugget+sill*(1-exp(-3*D/range)));
n=length(x);
G_mod(:,n+1)=1;
G_mod(n+1,:)=1;
G_mod(n+1,n+1)=0;
G_inv=inv(G_mod);
S=0.5:1:39.5;R=0.5:1:49.5
[Xg2,Xg1]=meshgrid(R,S);
Xg=reshape(Xg1,[],1);
Yg=reshape(Xg2,[],1);
Zg=Xg*NaN;
s2_k=Xg*NaN;
for  k=1:length(Xg)
  DOR=((x-Xg(k)).^2+(y-Yg(k)).^2).^0.5
  G_R=(nugget+sill*(1-exp(-3*DOR/range)));
  G_R(n+1)=1;
   E=G_inv*G_R;
   Zg(k)=sum(E(1:n,1).*z);
   s2_k(k)=sum(E(1:n,1).*G_R(1:n,1))+E(n+1,1);
end
fid = fopen('c2.txt','w');
fprintf(fid,'%g\n',Zg)  
fclose(fid);
