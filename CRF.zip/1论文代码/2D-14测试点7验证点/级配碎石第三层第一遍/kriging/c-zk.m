A=textread('c.txt')
B=textread('c1.txt')
C=textread('c2.txt')
D=A+B-C

fid = fopen('c-zk.txt','w');
fprintf(fid,'%g\n',D)  
fclose(fid);