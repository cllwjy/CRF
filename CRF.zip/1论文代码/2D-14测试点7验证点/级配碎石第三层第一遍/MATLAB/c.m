clear
clc
mu=31.1; sigma=11.9; %��ֵ����׼��
lx=20;ly=20;%������Χ

C=textread('c1.txt'); 
mLem=length(C); 

ACF=1;
% ACF=1 ; ACF=2 ; ACF=3 ; ACF=4 
for k=1
pxy=zeros(mLem); 
for i=1:mLem 
   for j=1:mLem 
        dx=abs(C(i,1)-C(j,1)); 
        dy=abs(C(i,2)-C(j,2)); 
     switch ACF             
         case 1           
      pxy(i,j)=exp(-2*dx/lx-2*dy/ly);
    end 
  end 
 end 
PXY(:,:,k)=pxy; 
end 

for k=1
      L2(:,:,k)=chol(PXY(:,:,k))'; 
end 

Nsim=1;
randn('state',0);rand('state',0); 
UU=lhsnorm(zeros(2*mLem,1),eye(2*mLem), Nsim)'; 

for imod=1:Nsim 
     U=[UU(1:mLem,imod)];
     H0=[L2(:,:,1)*U(:,1)];
    c(:,imod)=mu+sigma*H0(:,1); 
      
end 
return 
fid = fopen('c.txt','wt');
fprintf(fid,'%g\n',c)  
fclose(fid);
b=reshape(c,16,100);
xx=[1:100];
yy=[1:16];
%[xx,yy]=meshgrid(1:100,1:16); %x����Ϊ1,2,3����100��y����Ϊ1,2,3����16
pcolor(xx,yy,b)
axis equal tight
colorbar


