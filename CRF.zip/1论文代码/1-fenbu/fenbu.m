clear clc
%%
x=textread('R1.txt');
% ��Ƶ�ʷֲ�ֱ��ͼ
[counts,centers] = hist(x,5);
figure;
bar(centers,counts/sum(counts));
legend('Third layer of graded crushed stone-Pass 1','Fontname', 'Times New Roman','FontSize',16);
set(gca,'FontSize',18,'FontName','Times New Roman')
%set(gca,'ylim',[0,0.7],'ytick',[0:0.1:0.7]);%y�����᷶Χ
xlabel('EVD (MPa)','Fontname', 'Times New Roman','FontSize',18);
ylabel('Frequency ','Fontname', 'Times New Roman','FontSize',18);
hold on;
%%
x=textread('R2.txt');
% ��Ƶ�ʷֲ�ֱ��ͼ
[counts,centers] = hist(x,5);
figure;
bar(centers,counts/sum(counts));
legend('Third layer of graded crushed stone-Pass 2','Fontname', 'Times New Roman','FontSize',16);
set(gca,'FontSize',18,'FontName','Times New Roman')
set(gca,'ylim',[0,0.35],'ytick',[0:0.1:0.35]);%y�����᷶Χ
xlabel('EVD (MPa)','Fontname', 'Times New Roman','FontSize',18);
ylabel('Frequency ','Fontname', 'Times New Roman','FontSize',18);
hold on;
%%
x=textread('R3.txt');
% ��Ƶ�ʷֲ�ֱ��ͼ
[counts,centers] = hist(x,5);
figure;
bar(centers,counts/sum(counts));
legend('Third layer of graded crushed stone-Pass 3','Fontname', 'Times New Roman','FontSize',16);
set(gca,'FontSize',18,'FontName','Times New Roman')
set(gca,'ylim',[0,0.4],'ytick',[0:0.1:0.4]);%y�����᷶Χ
xlabel('EVD (MPa)','Fontname', 'Times New Roman','FontSize',18);
ylabel('Frequency ','Fontname', 'Times New Roman','FontSize',18);
hold on;
%%
x=textread('R4.txt');
% ��Ƶ�ʷֲ�ֱ��ͼ
[counts,centers] = hist(x,5);
figure;
bar(centers,counts/sum(counts));
legend('Third layer of graded crushed stone-Pass 4','Fontname', 'Times New Roman','FontSize',16);
set(gca,'FontSize',18,'FontName','Times New Roman')
set(gca,'ylim',[0,0.3],'ytick',[0:0.1:0.3]);%y�����᷶Χ
xlabel('EVD (MPa)','Fontname', 'Times New Roman','FontSize',18);
ylabel('Frequency ','Fontname', 'Times New Roman','FontSize',18);
hold on;
%%
x=textread('R5.txt');
% ��Ƶ�ʷֲ�ֱ��ͼ
[counts,centers] = hist(x,5);
figure;
bar(centers,counts/sum(counts));
legend('Third layer of graded crushed stone-Final pass','Fontname', 'Times New Roman','FontSize',15);
set(gca,'FontSize',18,'FontName','Times New Roman')
set(gca,'ylim',[0,0.4],'ytick',[0:0.1:0.4]);%y�����᷶Χ
xlabel('EVD (MPa)','Fontname', 'Times New Roman','FontSize',18);
ylabel('Frequency ','Fontname', 'Times New Roman','FontSize',18);
hold on;
%%
x=textread('R6.txt');
% ��Ƶ�ʷֲ�ֱ��ͼ
[counts,centers] = hist(x,5);
figure;
bar(centers,counts/sum(counts));
legend('Cement stabilized macadam lower base-Final pass','Fontname', 'Times New Roman','FontSize',14);
set(gca,'FontSize',18,'FontName','Times New Roman')
set(gca,'ylim',[0,0.42],'ytick',[0:0.1:0.4]);%y�����᷶Χ
xlabel('EVD (MPa)','Fontname', 'Times New Roman','FontSize',18);
ylabel('Frequency ','Fontname', 'Times New Roman','FontSize',18);
hold on;
%%
x=textread('R7.txt');
% ��Ƶ�ʷֲ�ֱ��ͼ
[counts,centers] = hist(x,5);
figure;
bar(centers,counts/sum(counts));
legend('Cement stabilized macadam upper base-Final pass','Fontname', 'Times New Roman','FontSize',14);
set(gca,'FontSize',18,'FontName','Times New Roman')
set(gca,'ylim',[0,0.3],'ytick',[0:0.1:0.3]);%y�����᷶Χ
xlabel('EVD (MPa)','Fontname', 'Times New Roman','FontSize',18);
ylabel('Frequency ','Fontname', 'Times New Roman','FontSize',18);
hold on;