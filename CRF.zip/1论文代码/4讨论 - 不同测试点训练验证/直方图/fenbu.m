clear clc
%%
x=textread('d.txt');
% ��Ƶ�ʷֲ�ֱ��ͼ
[counts,centers] = hist(x,5);
figure;
bar(centers,counts/sum(counts));
legend('Runway experimental section','Fontname', 'Times New Roman','FontSize',24);
xlabel('EVD/MPa','Fontname', 'Times New Roman','FontSize',24);
ylabel('Frequency ','Fontname', 'Times New Roman','FontSize',24);
hold on;