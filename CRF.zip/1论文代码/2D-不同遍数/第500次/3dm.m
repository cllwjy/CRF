clear clc;
close all;
load C1500.mat;
load C2500.mat;
load C3500.mat;
load C4500.mat;
load C5500.mat;
a1=C1500;
a1=flip(a1,2);
a2=C2500;
a2=flip(a2,2);
a3=C3500;
a3=flip(a3,2);
a4=C4500;
a4=flip(a4,2);
a5=C5500;
a5=flip(a5,2);
c=cat(3,a1,a2,a3,a4,a5);

[x,y,z]=meshgrid(1:16,1:100,1:5);
xslice=[];
yslice=[];
zslice=[1 2 3 4 5];
slice(x,y,z,c,xslice,yslice,zslice);
shading interp;
colormap(jet);
grid off
 colormap(gca, 'hsv')
colorbar;
set(gca,'ylim',[0,100],'ytick',[0:20:100]);
set(gca,'zlim',[0,5]);
set(gca,'FontName','Times New Roman','FontSize',12,'LineWidth',0.5);
% xlim([0,12]);
% ylim([0,12]);
% % zlim([0,24]);
xlabel('Y/m'); %�����������ǩ
ylabel('X/m');
zlabel('EVD/MPa');
view(44,45);  % �ӽ��趨