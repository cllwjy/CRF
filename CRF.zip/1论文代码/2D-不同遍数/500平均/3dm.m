clear clc;
close all;
load 1.mat;
load 2.mat;
load 3.mat;
load 4.mat;
load 5.mat;
a1=b1;
a1=flip(a1,2);
a2=b2;
a2=flip(a2,2);
a3=b3;
a3=flip(a3,2);
a4=b4;
a4=flip(a4,2);
a5=b5;
a5=flip(a5,2);
c=cat(3,a1,a2,a3,a4,a5);

[x,y,z]=meshgrid(1:16,1:100,1:5);
xslice=[];
yslice=[];
zslice=[1 2 3 4 5];
slice(x,y,z,c,xslice,yslice,zslice);
shading interp;
colormap(jet);
grid on
 colormap(gca, 'parula')
colorbar;
% xlim([0,12]);
% ylim([0,12]);
% % zlim([0,24]);
% xlabel('Latitude/(��N)','rotation',-12); %�����������ǩ
% ylabel('Longitude/(��E)','rotation',12);
% zlabel('Altitude/(km)');
view(44,45);  % �ӽ��趨